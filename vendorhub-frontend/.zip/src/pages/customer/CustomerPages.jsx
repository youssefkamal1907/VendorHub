import React, { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { productAPI, orderAPI, favoriteAPI, reviewAPI } from '../../services/api';
import { Layout } from '../../components/layout/Sidebar';

// ─── Shop / Browse ────────────────────────────────────────────────────────────
export function ShopPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ category: '', search: '', minPrice: '', maxPrice: '' });
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [selected, setSelected] = useState(null);
  const pageSize = 12;

  const load = (p = 1) => {
    setLoading(true);
    productAPI.browse({ ...filters, page: p, pageSize })
      .then(res => { setProducts(res.data.data?.items || []); setTotal(res.data.data?.total || 0); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(1); setPage(1); }, [filters]); // eslint-disable-line

  const categories = ['Electronics', 'Clothing', 'Books', 'Home & Garden', 'Sports', 'Food', 'Beauty', 'Toys', 'Other'];

  return (
    <Layout>
      <div className="page-header">
        <h1 className="page-title">Shop</h1>
        <div style={{ color: 'var(--text-muted)', fontSize: 14 }}>{total} products</div>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 24, flexWrap: 'wrap' }}>
        <input className="input" style={{ maxWidth: 260 }} placeholder="🔍 Search products..." value={filters.search}
          onChange={e => setFilters(f => ({ ...f, search: e.target.value }))} />
        <select className="input" style={{ maxWidth: 180 }} value={filters.category}
          onChange={e => setFilters(f => ({ ...f, category: e.target.value }))}>
          <option value="">All Categories</option>
          {categories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <input className="input" style={{ maxWidth: 120 }} type="number" placeholder="Min $" value={filters.minPrice}
          onChange={e => setFilters(f => ({ ...f, minPrice: e.target.value }))} />
        <input className="input" style={{ maxWidth: 120 }} type="number" placeholder="Max $" value={filters.maxPrice}
          onChange={e => setFilters(f => ({ ...f, maxPrice: e.target.value }))} />
      </div>

      {loading ? <div className="loader"><div className="spinner" /></div>
        : products.length === 0
          ? <div className="empty"><div className="empty-icon">🔍</div>No products found</div>
          : (
            <>
              <div className="product-grid">
                {products.map(p => (
                  <div key={p.id} className="product-card" onClick={() => setSelected(p)}>
                    <div className="product-card-img">
                      {p.images?.[0] ? <img src={p.images[0]} alt={p.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : '📦'}
                    </div>
                    <div className="product-card-body">
                      <div className="product-card-title">{p.title}</div>
                      <div className="product-card-price">${p.price}</div>
                      <div className="product-card-meta">
                        {p.category} · {p.availableUnits} in stock
                        {p.averageRating > 0 && <span> · ⭐ {p.averageRating.toFixed(1)}</span>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pagination */}
              {total > pageSize && (
                <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 28 }}>
                  <button className="btn btn-ghost" disabled={page === 1} onClick={() => { setPage(p => p - 1); load(page - 1); }}>← Prev</button>
                  <span style={{ padding: '10px 16px', color: 'var(--text-muted)' }}>Page {page} of {Math.ceil(total / pageSize)}</span>
                  <button className="btn btn-ghost" disabled={page >= Math.ceil(total / pageSize)} onClick={() => { setPage(p => p + 1); load(page + 1); }}>Next →</button>
                </div>
              )}
            </>
          )}

      {/* Product Detail Modal */}
      {selected && <ProductModal product={selected} onClose={() => setSelected(null)} />}
    </Layout>
  );
}

// ─── Product Detail Modal ─────────────────────────────────────────────────────
function ProductModal({ product, onClose }) {
  const [qty, setQty] = useState(1);
  const [ordering, setOrdering] = useState(false);
  const [reviews, setReviews] = useState([]);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });
  const [addingReview, setAddingReview] = useState(false);

  useEffect(() => {
    reviewAPI.getByProduct(product.id).then(res => setReviews(res.data.data || []));
  }, [product.id]);

  const placeOrder = async () => {
    if (qty < 1 || qty > product.availableUnits) return toast.error('Invalid quantity');
    setOrdering(true);
    try {
      await orderAPI.place({ productId: product.id, quantity: qty });
      toast.success('Order placed! 🎉');
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Order failed');
    } finally { setOrdering(false); }
  };

  const addToFavs = async () => {
    try { const res = await favoriteAPI.toggle(product.id); toast.success(res.data.message); }
    catch { toast.error('Failed'); }
  };

  const submitReview = async () => {
    if (!newReview.comment) return toast.error('Write a comment');
    setAddingReview(true);
    try {
      const res = await reviewAPI.add({ productId: product.id, ...newReview });
      setReviews(r => [res.data.data, ...r]);
      setNewReview({ rating: 5, comment: '' });
      toast.success('Review added!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed');
    } finally { setAddingReview(false); }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" style={{ maxWidth: 620 }} onClick={e => e.stopPropagation()}>
        {product.images?.[0] && (
          <img src={product.images[0]} alt={product.title} style={{ width: '100%', height: 220, objectFit: 'cover', borderRadius: 10, marginBottom: 20 }} />
        )}

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <h2 style={{ fontSize: 22 }}>{product.title}</h2>
            <div style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 4 }}>
              by {product.vendorName} · {product.category}
            </div>
          </div>
          <div style={{ fontSize: 26, fontWeight: 800, color: 'var(--accent)' }}>${product.price}</div>
        </div>

        <p style={{ color: 'var(--text-muted)', fontSize: 14, margin: '14px 0' }}>{product.description}</p>

        <div style={{ display: 'flex', gap: 16, fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>
          <span>📦 {product.availableUnits} in stock</span>
          <span>👁️ {product.numberOfViewers} views</span>
          {product.averageRating > 0 && <span>⭐ {product.averageRating.toFixed(1)} ({product.reviewCount})</span>}
        </div>

        {/* Buy / Favorite */}
        <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 24 }}>
          <input type="number" className="input" min={1} max={product.availableUnits} value={qty}
            onChange={e => setQty(parseInt(e.target.value))}
            style={{ maxWidth: 80 }} />
          <button className="btn btn-primary" onClick={placeOrder} disabled={ordering || product.availableUnits === 0}>
            {product.availableUnits === 0 ? 'Out of Stock' : ordering ? 'Placing...' : '🛒 Buy Now'}
          </button>
          <button className="btn btn-ghost" onClick={addToFavs}>❤️ Favorite</button>
        </div>

        {/* Reviews */}
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: 20 }}>
          <h3 style={{ fontSize: 16, marginBottom: 14 }}>Reviews ({reviews.length})</h3>

          {/* Add review */}
          <div style={{ background: 'var(--bg3)', borderRadius: 8, padding: 14, marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
              <label style={{ fontSize: 13, color: 'var(--text-muted)' }}>Rating:</label>
              <select className="input" style={{ width: 80 }} value={newReview.rating}
                onChange={e => setNewReview(r => ({ ...r, rating: parseInt(e.target.value) }))}>
                {[5, 4, 3, 2, 1].map(n => <option key={n} value={n}>{'⭐'.repeat(n)}</option>)}
              </select>
            </div>
            <textarea className="input" rows={2} placeholder="Write a review (must have purchased)..." value={newReview.comment}
              onChange={e => setNewReview(r => ({ ...r, comment: e.target.value }))} />
            <button className="btn btn-primary" style={{ marginTop: 8, padding: '8px 16px', fontSize: 13 }}
              onClick={submitReview} disabled={addingReview}>
              {addingReview ? 'Submitting...' : 'Submit Review'}
            </button>
          </div>

          {reviews.length === 0
            ? <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>No reviews yet</div>
            : reviews.map(r => (
              <div key={r.id} style={{ borderBottom: '1px solid var(--border)', paddingBottom: 12, marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontWeight: 600, fontSize: 14 }}>{r.customerName}</span>
                  <span>{'⭐'.repeat(r.rating)}</span>
                </div>
                <div style={{ fontSize: 14, color: 'var(--text-muted)' }}>{r.comment}</div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}

// ─── Favorites ────────────────────────────────────────────────────────────────
export function FavoritesPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    favoriteAPI.getAll().then(res => setProducts(res.data.data || [])).finally(() => setLoading(false));
  }, []);

  return (
    <Layout>
      <div className="page-header"><h1 className="page-title">❤️ Favorites</h1></div>
      {loading ? <div className="loader"><div className="spinner" /></div>
        : products.length === 0
          ? <div className="empty"><div className="empty-icon">❤️</div>No favorites yet</div>
          : (
            <div className="product-grid">
              {products.map(p => (
                <div key={p.id} className="product-card" onClick={() => setSelected(p)}>
                  <div className="product-card-img">
                    {p.images?.[0] ? <img src={p.images[0]} alt={p.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : '📦'}
                  </div>
                  <div className="product-card-body">
                    <div className="product-card-title">{p.title}</div>
                    <div className="product-card-price">${p.price}</div>
                    <div className="product-card-meta">{p.category}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
      {selected && <ProductModal product={selected} onClose={() => setSelected(null)} />}
    </Layout>
  );
}

// ─── Customer Orders ──────────────────────────────────────────────────────────
export function CustomerOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    orderAPI.myOrders().then(res => setOrders(res.data.data || [])).finally(() => setLoading(false));
  }, []);

  return (
    <Layout>
      <div className="page-header"><h1 className="page-title">My Orders</h1></div>
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        {loading ? <div className="loader"><div className="spinner" /></div>
          : orders.length === 0
            ? <div className="empty"><div className="empty-icon">📋</div>No orders yet</div>
            : (
              <table className="table">
                <thead><tr><th>Product</th><th>Qty</th><th>Total</th><th>Status</th><th>Date</th></tr></thead>
                <tbody>
                  {orders.map(o => (
                    <tr key={o.id}>
                      <td style={{ fontWeight: 600 }}>{o.productTitle}</td>
                      <td>{o.quantity}</td>
                      <td style={{ color: 'var(--accent)', fontWeight: 700 }}>${o.totalPrice.toFixed(2)}</td>
                      <td><span className="badge badge-approved">{o.status}</span></td>
                      <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{new Date(o.createdAt).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
      </div>
    </Layout>
  );
}
